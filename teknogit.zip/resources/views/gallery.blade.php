@extends('layouts.main')

@section('title', 'Teknomarket Galeria')

@section('content')

<div style=" display : none ">
{{$data}}
</div>



@endsection