<?php $__env->startSection('title', 'Teknomarket Galeria'); ?>

<?php $__env->startSection('content'); ?>

<div id="galleryContent">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($element->serie%2!=0): ?>
<span>
    <div class="row">
<?php endif; ?>


        <div class="col-md-3"> 
            
        <img class="col-md-12" src="<?php echo e($element->img); ?>" alt=""> 
            
        </div>
        <div class="col-md-3"> 
            <h3><?php echo e($element->modelo); ?> <small> <?php echo e($element->precio); ?>&#8364;</small></h3>
            <h4>Descuento <?php echo e($element->oferta); ?>%</h4>
            <br>
            <button class="btn btn-primary"  onclick="
                 console.log(<?php echo e($element->serie); ?>);                                   
                                                      
            "> <h4>Añadir al carro</h4> </button> 
        </div>
    

<?php if($element->serie%2==0): ?>
    </div>
    <hr>
</span>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
        <script> 
        localStorage.setItem ("Page",1);
           $('#galleryContent').easyPaginate({
                paginateElement: 'span',
                elementsPerPage: 3,
           });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>