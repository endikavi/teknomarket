<?php $__env->startSection('title', 'Teknomarket'); ?>

<?php $__env->startSection('content'); ?>

    <p>This is my body content.</p>

    <?php if(1==2): ?>
        <p>Estoy en el if</p>
    <?php else: ?>
        <p>No estoy en el if</p>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>