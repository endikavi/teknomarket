<?php $__env->startSection('navbar'); ?>
    ##parent-placeholder-c63e3c1cfa2ff651ad4cfadea3e21265ffcf8ca3##
    <?php if(Route::has('login')): ?>
        <div class="top-right links">
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/home')); ?>">Principal</a>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>">Entrar</a>
            <a href="<?php echo e(route('register')); ?>">Registrarse</a>
        <?php endif; ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>